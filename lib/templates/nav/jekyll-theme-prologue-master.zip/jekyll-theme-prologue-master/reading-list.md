---
title: Reading List
subtitle: a list of books I read
layout: "page"
icon: fa-book
order: 3
---

I love books! Here are some I'm reading now:

1. Robert Burton: *The Anatomy of Melancholy*
2. Robert Musil: *The Man Without Qualities*
3. Kazuo Ishiguro: *The Unconsoled*
4. Malcolm Lowry: *Under the Volcano*
5. Virginia Woolf: *The Waves*
6. James Joyce: *Finnegans Wake*
7. Thomas Wolfe: *Look Homeward, Angel*
8. William Thackeray: *Pendennis*
9. Karl Marx: *Capital*
10. James Woodforde: *The Diary of A Country Parson*

source: [The Guardian](https://www.theguardian.com/books/booksblog/2011/jan/04/best-boring-books)