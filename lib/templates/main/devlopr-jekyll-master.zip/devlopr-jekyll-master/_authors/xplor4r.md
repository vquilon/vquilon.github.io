---
name: Sujay Kundu
username: xplor4r
bio: "Full Stack Web Developer, based in Bangalore, India"
site: https://sujaykundu.com
avatar: xplor4r.png
email: mail@sujaykundu.com
social:
    - title: "github"
      url: "https://github.com/sujaykundu777"
    - title: "linkedin"
      url: "https://www.linkedin.com/in/sujaykundu"
    - title: "youtube"
      url: "https://www.youtube.com/channel/UCSfLBFFfNU9r6ihfei6VeJw"
    - title: "facebook"
      url: "https://www.facebook.com/sujay.kundu2"
---