---
layout: gallery
title: Mountains
---

{% include gallery-layout.html gallery=site.data.galleries.mountains %}
