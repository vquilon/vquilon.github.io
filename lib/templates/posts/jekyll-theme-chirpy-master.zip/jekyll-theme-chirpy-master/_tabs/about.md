---
title: About
icon: fas fa-info
order: 4

# The About page
# v2.0
# https://github.com/cotes2020/jekyll-theme-chirpy
# © 2017-2019 Cotes Chung
# MIT License
---


> **Note**: Add Markdown syntax content to file `_tabs/about.md` and it will show up on this page.
